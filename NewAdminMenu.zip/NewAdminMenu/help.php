<div id="settings_form" style="border: solid #ccc 1px; -webkit-box-shadow: 0 1px 1px #ccc; -moz-box-shadow: 0 1px 1px #ccc; box-shadow: 0 1px 1px #ccc;padding: 20px;">
           <fieldset>
                <legend>
                    <h1 style="font-size: 20px; font-weight: normal;">A better menu system for admin</h1>
                </legend>
                
                <p>
                    You only need to install or uninstall and it helps with mobile use
                </p>
                
            </fieldset>
        </div>