<?php
 /*
Plugin Name: New Menu For Admin
Plugin URI: - http://www.osclass.org/
Description: This plugin enables a better menu for admin
Version: 1.0.1
Author: TradeMyBike
Author URI: - http://www.osclass.org/
Short Name: NewAdminMenu
Plugin update URI: newadminmenu
*/

function osc_admin_toolbar_newmenu()
{
    AdminToolbar::newInstance()->add_menu( array(
                'id'        => 'newmenu',
                'title'     => ' <div class="handle">&nbsp;Menu</div>',
                'href'      => '#',
                'meta'      => array('class' => 'btn btn-dim fa fa-bars float-left')
            
            ) );
          
}
function NewAdminMenuFooter() {
?>
<style>
#sidebar {display:none!important;}
#content {margin-left:0!important;}
.float-right {float:left!important;}
#sidebar2{margin-top:60px; }
#sidebar2 ul#menu{ position:absolute;   height:3em;  margin:0 30px 10px 0;  padding:0;  background:#111;  color:#eee;  box-shadow:0 -1px rgba(0,0,0,.5) inset;}
#sidebar2 ul#menu > li{  float:left;width:260px;background:#555;  list-style-type:none;padding:0.5em 0 0.5em 0;  position:relative;}
#sidebar2 label{  position:relative;width:260px;  display:block;  padding:0 18px 0 12px;  line-height:3em;  transition:background 0.3s;  cursor:pointer;}
#sidebar2 label:after{  content:"";  position:absolute;  display:block;  top:50%;  right:5px;  width:0;  height:0;  border-top:4px solid rgba(255,255,255,.5);  border-bottom:0 solid rgba(255,255,255,.5);
  border-left:4px solid transparent;  border-right:4px solid transparent;  transition:border-bottom .1s, border-top .1s .1s;  }
#sidebar2 label:hover,#sidebar2 input:checked ~ label{background:rgba(0,0,0,.3);}
#sidebar2 input:checked ~ label:after{  border-top:0 solid rgba(255,255,255,.5);  border-bottom:4px solid rgba(255,255,255,.5);  transition:border-top .1s, border-bottom .1s .1s;}
#sidebar2 input{display:none}
#sidebar2 input:checked ~ ul.submenu{  max-height:350px;  transition:max-height 0.5s ease-in;}
#sidebar2  ul.submenu{  max-height:0;  padding:0;  overflow:auto;  list-style-type:none;z-index:1; background:#f4f78d;   transition:max-height 0.5s ease-out;  position:absolute;  min-width:100%;}
#sidebar2  ul.submenu li a{  display:block;  padding:12px;  color:#000 !important;  text-decoration:none; font-weight:600;}
#sidebar2  ul.submenu li a:hover{  background:rgba(0,0,0,.3);}
.handle{float:right;margin-right:2px;}
</style>
<script>
 $(document).ready(function() {
     $('#sidebar2 ul').hide(); 
                $('.handle').on('click', function() {
                    $('#sidebar2 ul').slideToggle();
                });

            });
           

        </script>
  <?php
    }
function NewAdminMenuHeader() {
?>
<style>
#sidebar2 .hide {display: none;}
</style>
  <?php
    }
function NewAdminMenuTitle($title){
	        $title = 'New Admin Menu <a href="'.osc_admin_render_plugin_url(osc_plugin_folder(__FILE__) . 'help.php') . '" class="btn ico ico-32 ico-engine float-left">Help</a>';
 
			return $title;
	 }
	 if( osc_version() >= 300){
		 $file = explode('/', Params::getParam('file'));
	     if($file[0] == 'NewAdminMenu'){
			osc_add_filter('custom_plugin_title','NewAdminMenuTitle');
		 }
	 }
 
function NewAdminMenu()
    {

        $actual_url  = urldecode(Params::getServerParam('QUERY_STRING', false, false));
        $actual_page = Params::getParam('page');
        $something_selected = false;
        $adminMenu          = AdminMenu::newInstance();
        $aMenu              = $adminMenu->get_array_menu();
        $current_menu_id    = osc_current_menu();
        $is_moderator       = osc_is_moderator();
        ob_start();
        osc_run_hook('admin_menu');
        $plugins_out = ob_get_contents();
        ob_end_clean();
        $plugins_out = preg_replace('|<h3><a .*>(.*)</a></h3>|', '<li class="submenu-divide">$1</li>', $plugins_out);
        $plugins_out = preg_replace('|<ul>|', '', $plugins_out);
        $plugins_out = preg_replace('|</ul>|', '', $plugins_out);

        $sub_current = false;
        $sMenu = '<!-- menu -->'.PHP_EOL;
        
        $sMenu .= '<div id="sidebar2">'.PHP_EOL;
        $sMenu .= '<ul id="menu hide">'.PHP_EOL;

        $current_menu = '';
        $priority = 0;
        $urlLenght = 0;

        foreach($aMenu as $key => $value) {
            // --- submenu section
            if( array_key_exists('sub', $value) ) {
                $aSubmenu = $value['sub'];
                foreach($aSubmenu as $aSub) {
                    $credential_sub = isset($aSub[4])?$aSub[4]:$aSub[3];

                    if(!$is_moderator || ($is_moderator && $credential_sub == 'moderator')) { // show

                        $url_submenu   = $aSub[1];
                        $url_submenu   = str_replace(osc_admin_base_url(true).'?', '', $url_submenu);
                        $url_submenu   = str_replace(osc_admin_base_url(), '', $url_submenu);

                        if( strpos($actual_url, $url_submenu, 0) === 0 && $priority<=2  && $url_submenu != '') {

                            if( $urlLenght<strlen($url_submenu) ) {
                                $urlLenght = strlen($url_submenu);
                                $sub_current = true;
                                $current_menu = $value[2];
                                $priority  = 2;
                            }
                        } else if( $actual_page == $value[2] && $priority<1 ) {
                            $sub_current = true;
                            $current_menu = $value[2];
                            $priority  = 1;
                        }
                    }
                }
            }

            // --- menu section
            $url_menu   = $value[1];
            $url_menu   = str_replace(osc_admin_base_url(true).'?', '', $url_menu);
            $url_menu   = str_replace(osc_admin_base_url(), '', $url_menu);

            if(@strpos($actual_url, $url_menu) === 0  && $priority<=2 && $url_menu != '') {
                if( $urlLenght<strlen($url_menu) ) {
                    $urlLenght = strlen($url_menu);
                    $sub_current = true;
                    $current_menu = $value[2];
                    $priority  = 2;
                }
            } else if($actual_page == $value[2] &&  $priority<1 ) {
                $sub_current = true;
                $current_menu = $value[2];
                $priority  = 1;
            } else if($url_menu == $actual_page) {
                $sub_current = true;
                $current_menu = $value[2];
                $priority  = 0;
            }
        }
        $value = array();
        foreach($aMenu as $key => $value) {

            $sSubmenu   = "";
            $credential = $value[3];
            if(!$is_moderator || $is_moderator && $credential == 'moderator') { // show

                $class      = '';
                if( array_key_exists('sub', $value) ) {
                    $aSubmenu = $value['sub'];
                    if($aSubmenu) {
                        
                      $sSubmenu .= '<input id="check'.$value[2].'" type="checkbox" name="menu"/>'.PHP_EOL;
                      $sSubmenu .= '<label for="check'.$value[2].'">'.$value[0].'</label>'.PHP_EOL;
                       $sSubmenu .= '<ul class="submenu">'.PHP_EOL;
                        foreach($aSubmenu as $aSub) {
                            $credential_sub = isset($aSub[4])?$aSub[4]:$aSub[3];
                            if(!$is_moderator || $is_moderator && $credential_sub == 'moderator') { // show
                                if(substr($aSub[1], 0, 8)=="divider_") {
                                    $sSubmenu .= '<li>'.$aSub[0].'</li>'.PHP_EOL;
                                    } else {
                                    $sSubmenu .= '<li><a id="'.$aSub[2].'" href="'.$aSub[1].'">'.$aSub[0].'</a></li>'.PHP_EOL;
                                }
                            }
                        }
                        
                        if($key == 'plugins' && !$is_moderator) {
                            $sSubmenu .= $plugins_out;
                        }

                        $sSubmenu .= "</ul>".PHP_EOL;
                    }
                    
                    
                    
                }
                else {
                 $sSubmenu .= '<a id="'.$value[1].'" href="'.$value[1].'"><label for="check'.$value[2].'">'.$value[0].'</label></a>'.PHP_EOL;   
                }
                $class = osc_apply_filter('current_admin_menu_'.$value[2],$class);

                if( $current_menu == $value[2] ) { $class = 'current'; }
                
                $sMenu .= '<li id="menu_'.$value[2].'" class="'.$class.'">'.PHP_EOL;
                $sMenu .= $sSubmenu;
                $sMenu .= '</li>'.PHP_EOL;
                
            }

        }
        $sMenu .= '</ul>'. PHP_EOL;
        $sMenu .= '</div>'.PHP_EOL;
        $sMenu .= '<!-- menu end -->'.PHP_EOL;
        echo $sMenu;
    }

function NewAdminMenu_admin_menu() { 
echo '<h3><a href="#">New Admin Menu</a></h3>
<ul><li><a href="' . osc_admin_render_plugin_url(osc_plugin_folder(__FILE__) . 'help.php') . '">' . __('Read Me / Help', 'NewAdminMenu') . '</a></li>
</ul>'; 
}
function NewAdminMenu_configure() {
	osc_admin_render_plugin('NewAdminMenu/help.php');
}
osc_register_plugin(osc_plugin_path(__FILE__), 'NewAdminMenu_install');
osc_add_hook( osc_plugin_path( __FILE__ ) . '_configure', 'NewAdminMenu_configure' ) ;	
osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', 'NewAdminMenu_uninstall'); 
osc_add_hook('admin_menu', 'NewAdminMenu_admin_menu');
osc_add_hook('admin_header', 'NewAdminMenu',1);
osc_add_hook('admin_header', 'NewAdminMenuHeader',2);
osc_add_hook('add_admin_toolbar_menus', 'osc_admin_toolbar_newmenu', 2 );
osc_add_hook('admin_footer', 'NewAdminMenuFooter',1);
?>